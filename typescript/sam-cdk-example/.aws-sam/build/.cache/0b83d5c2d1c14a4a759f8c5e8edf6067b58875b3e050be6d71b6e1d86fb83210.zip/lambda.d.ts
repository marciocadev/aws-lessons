declare const axios: any;
declare const AWSXRay: any;
declare const AWS: any;
declare const db: any;
