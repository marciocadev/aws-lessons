"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
// if (process.env.AWS_SAM_LOCAL) {
//     var AWS = require('aws-sdk');
// }
// else {
//     const AWSXray = require('aws-xray-sdk');
//     var AWS = AWSXray.captureAWS(require('aws-sdk'));
// }
const Comprehend = require("aws-sdk/clients/comprehend");
const comprehend = new Comprehend();
/**
 *
 * @param event
 * @param context
 */
exports.handler = async (event, context) => {
    const txt = "I'm love my city, Rio de Janeiro is amazing, mas as vezes eu gostaria de morar em outro local.";
    var paramDominantLanguageRequest = {
        Text: txt
    };
    var paramDetectEntitiesRequest = {
        Text: txt,
        LanguageCode: 'en'
    };
    var paramDetectSentimentRequest = {
        Text: txt,
        LanguageCode: 'en'
    };
    try {
        const dominantLanguage = await comprehend.detectDominantLanguage(paramDominantLanguageRequest)
            .promise();
        const entityResult = await comprehend.detectEntities(paramDetectEntitiesRequest)
            .promise();
        const sentimentResult = await comprehend.detectSentiment(paramDetectSentimentRequest)
            .promise();
        const responseData = {
            dominantLanguage,
            entityResult,
            sentimentResult
        };
        return {
            statusCode: 200,
            body: responseData
        };
    }
    catch (err) {
        return {
            statusCode: 400,
            body: err
        };
    }
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxtQ0FBbUM7QUFDbkMsb0NBQW9DO0FBQ3BDLElBQUk7QUFDSixTQUFTO0FBQ1QsK0NBQStDO0FBQy9DLHdEQUF3RDtBQUN4RCxJQUFJO0FBQ0oseURBQXlEO0FBQ3pELE1BQU0sVUFBVSxHQUFHLElBQUksVUFBVSxFQUFFLENBQUM7QUFFcEM7Ozs7R0FJRztBQUNVLFFBQUEsT0FBTyxHQUFHLEtBQUssRUFBQyxLQUFVLEVBQUUsT0FBWSxFQUFFLEVBQUU7SUFFckQsTUFBTSxHQUFHLEdBQVcsZ0dBQWdHLENBQUM7SUFFckgsSUFBSSw0QkFBNEIsR0FBNkM7UUFDekUsSUFBSSxFQUFFLEdBQUc7S0FDWixDQUFBO0lBQ0QsSUFBSSwwQkFBMEIsR0FBcUM7UUFDL0QsSUFBSSxFQUFFLEdBQUc7UUFDVCxZQUFZLEVBQUUsSUFBSTtLQUNyQixDQUFBO0lBQ0QsSUFBSSwyQkFBMkIsR0FBc0M7UUFDakUsSUFBSSxFQUFFLEdBQUc7UUFDVCxZQUFZLEVBQUUsSUFBSTtLQUNyQixDQUFBO0lBRUQsSUFBSTtRQUNBLE1BQU0sZ0JBQWdCLEdBQ2xCLE1BQU0sVUFBVSxDQUFDLHNCQUFzQixDQUFDLDRCQUE0QixDQUFDO2FBQ2hFLE9BQU8sRUFBRSxDQUFDO1FBRW5CLE1BQU0sWUFBWSxHQUNkLE1BQU0sVUFBVSxDQUFDLGNBQWMsQ0FBQywwQkFBMEIsQ0FBQzthQUN0RCxPQUFPLEVBQUUsQ0FBQztRQUVuQixNQUFNLGVBQWUsR0FDakIsTUFBTSxVQUFVLENBQUMsZUFBZSxDQUFDLDJCQUEyQixDQUFDO2FBQ3hELE9BQU8sRUFBRSxDQUFDO1FBRW5CLE1BQU0sWUFBWSxHQUFHO1lBQ2pCLGdCQUFnQjtZQUNoQixZQUFZO1lBQ1osZUFBZTtTQUNsQixDQUFBO1FBQ0QsT0FBTztZQUNILFVBQVUsRUFBRSxHQUFHO1lBQ2YsSUFBSSxFQUFFLFlBQVk7U0FDckIsQ0FBQTtLQUNKO0lBQUMsT0FBTyxHQUFHLEVBQUU7UUFDVixPQUFPO1lBQ0gsVUFBVSxFQUFFLEdBQUc7WUFDZixJQUFJLEVBQUUsR0FBRztTQUNaLENBQUE7S0FDSjtBQUVMLENBQUMsQ0FBQSIsInNvdXJjZXNDb250ZW50IjpbIi8vIGlmIChwcm9jZXNzLmVudi5BV1NfU0FNX0xPQ0FMKSB7XG4vLyAgICAgdmFyIEFXUyA9IHJlcXVpcmUoJ2F3cy1zZGsnKTtcbi8vIH1cbi8vIGVsc2Uge1xuLy8gICAgIGNvbnN0IEFXU1hyYXkgPSByZXF1aXJlKCdhd3MteHJheS1zZGsnKTtcbi8vICAgICB2YXIgQVdTID0gQVdTWHJheS5jYXB0dXJlQVdTKHJlcXVpcmUoJ2F3cy1zZGsnKSk7XG4vLyB9XG5pbXBvcnQgKiBhcyBDb21wcmVoZW5kIGZyb20gJ2F3cy1zZGsvY2xpZW50cy9jb21wcmVoZW5kJztcbmNvbnN0IGNvbXByZWhlbmQgPSBuZXcgQ29tcHJlaGVuZCgpO1xuXG4vKipcbiAqIFxuICogQHBhcmFtIGV2ZW50IFxuICogQHBhcmFtIGNvbnRleHQgXG4gKi9cbmV4cG9ydCBjb25zdCBoYW5kbGVyID0gYXN5bmMoZXZlbnQ6IGFueSwgY29udGV4dDogYW55KSA9PiB7XG5cbiAgICBjb25zdCB0eHQ6IHN0cmluZyA9IFwiSSdtIGxvdmUgbXkgY2l0eSwgUmlvIGRlIEphbmVpcm8gaXMgYW1hemluZywgbWFzIGFzIHZlemVzIGV1IGdvc3RhcmlhIGRlIG1vcmFyIGVtIG91dHJvIGxvY2FsLlwiO1xuXG4gICAgdmFyIHBhcmFtRG9taW5hbnRMYW5ndWFnZVJlcXVlc3Q6IENvbXByZWhlbmQuRGV0ZWN0RG9taW5hbnRMYW5ndWFnZVJlcXVlc3QgPSB7XG4gICAgICAgIFRleHQ6IHR4dFxuICAgIH1cbiAgICB2YXIgcGFyYW1EZXRlY3RFbnRpdGllc1JlcXVlc3Q6IENvbXByZWhlbmQuRGV0ZWN0RW50aXRpZXNSZXF1ZXN0ID0ge1xuICAgICAgICBUZXh0OiB0eHQsXG4gICAgICAgIExhbmd1YWdlQ29kZTogJ2VuJ1xuICAgIH1cbiAgICB2YXIgcGFyYW1EZXRlY3RTZW50aW1lbnRSZXF1ZXN0OiBDb21wcmVoZW5kLkRldGVjdFNlbnRpbWVudFJlcXVlc3QgPSB7XG4gICAgICAgIFRleHQ6IHR4dCxcbiAgICAgICAgTGFuZ3VhZ2VDb2RlOiAnZW4nXG4gICAgfVxuXG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgZG9taW5hbnRMYW5ndWFnZTogQ29tcHJlaGVuZC5EZXRlY3REb21pbmFudExhbmd1YWdlUmVzcG9uc2UgPVxuICAgICAgICAgICAgYXdhaXQgY29tcHJlaGVuZC5kZXRlY3REb21pbmFudExhbmd1YWdlKHBhcmFtRG9taW5hbnRMYW5ndWFnZVJlcXVlc3QpXG4gICAgICAgICAgICAgICAgLnByb21pc2UoKTtcblxuICAgICAgICBjb25zdCBlbnRpdHlSZXN1bHQ6IENvbXByZWhlbmQuVHlwZXMuRGV0ZWN0RW50aXRpZXNSZXNwb25zZSA9IFxuICAgICAgICAgICAgYXdhaXQgY29tcHJlaGVuZC5kZXRlY3RFbnRpdGllcyhwYXJhbURldGVjdEVudGl0aWVzUmVxdWVzdClcbiAgICAgICAgICAgICAgICAucHJvbWlzZSgpO1xuICAgICAgICBcbiAgICAgICAgY29uc3Qgc2VudGltZW50UmVzdWx0OiBDb21wcmVoZW5kLlR5cGVzLkRldGVjdFNlbnRpbWVudFJlc3BvbnNlID1cbiAgICAgICAgICAgIGF3YWl0IGNvbXByZWhlbmQuZGV0ZWN0U2VudGltZW50KHBhcmFtRGV0ZWN0U2VudGltZW50UmVxdWVzdClcbiAgICAgICAgICAgICAgICAucHJvbWlzZSgpO1xuXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlRGF0YSA9IHtcbiAgICAgICAgICAgIGRvbWluYW50TGFuZ3VhZ2UsXG4gICAgICAgICAgICBlbnRpdHlSZXN1bHQsXG4gICAgICAgICAgICBzZW50aW1lbnRSZXN1bHRcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgc3RhdHVzQ29kZTogMjAwLFxuICAgICAgICAgICAgYm9keTogcmVzcG9uc2VEYXRhXG4gICAgICAgIH1cbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IDQwMCxcbiAgICAgICAgICAgIGJvZHk6IGVyclxuICAgICAgICB9XG4gICAgfVxuICAgIFxufVxuIl19