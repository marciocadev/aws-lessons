/**
 *
 * @param event
 * @param context
 */
export declare const handler: (event: any, context: any) => Promise<{
    statusCode: number;
    body: any;
}>;
