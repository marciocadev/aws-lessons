export declare const handler: (event: any, context: any) => Promise<{
    statusCode: number;
    body: string;
}>;
export declare const saveItem: (id: string, data: any) => Promise<void>;
